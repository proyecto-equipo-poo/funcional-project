package main;

import modelos.Playlist;
import modelos.UsuarioPremium;
import servicios.SistemaMusica;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("===== MOODMUSIC =====");

        System.out.print("Ingrese su nombre: ");
        String nombre = sc.nextLine();

        System.out.print("¿Cómo te sientes hoy?: ");
        String estado = sc.nextLine();

        UsuarioPremium usuario =
                new UsuarioPremium(
                        nombre,
                        estado,
                        "Playlists exclusivas");

        usuario.mostrarUsuario();
        usuario.mostrarBeneficio();

        SistemaMusica sistema =
                new SistemaMusica();

        Playlist playlist =
                sistema.generarPlaylist(estado);

        playlist.recomendar();

        System.out.println("\n🎶 Gracias por usar MoodMusic");
    }
}