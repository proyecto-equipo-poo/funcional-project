package modelos;

public class UsuarioPremium extends Usuario {

    private String beneficio;

    public UsuarioPremium(String nombre,
                          String estadoAnimo,
                          String beneficio) {

        super(nombre, estadoAnimo);

        this.beneficio = beneficio;
    }

    public void mostrarBeneficio() {

        System.out.println(
                "⭐ Beneficio Premium: " + beneficio);
    }
}