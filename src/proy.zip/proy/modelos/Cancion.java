package modelos;

public class Cancion {

    private String titulo;
    private String genero;
    private int duracion;

    public Cancion(String titulo, String genero, int duracion) {

        this.titulo = titulo;
        this.genero = genero;
        this.duracion = duracion;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getGenero() {
        return genero;
    }

    public int getDuracion() {
        return duracion;
    }

    public void mostrarCancion() {

        System.out.println(
                "🎵 " + titulo +
                        " | Género: " + genero +
                        " | Duración: " + duracion + " min");
    }
}