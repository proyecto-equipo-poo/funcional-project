package modelos;

import interfaces.Recomendable;
import java.util.ArrayList;

public class Playlist implements Recomendable {

    private String nombre;
    private ArrayList<Cancion> canciones;

    public Playlist(String nombre) {

        this.nombre = nombre;
        this.canciones = new ArrayList<>();
    }

    public void agregarCancion(Cancion c) {

        canciones.add(c);
    }

    public void mostrarPlaylist() {

        System.out.println("\n🎧 Playlist: " + nombre);

        for (Cancion c : canciones) {

            c.mostrarCancion();
        }
    }

    @Override
    public void recomendar() {

        System.out.println("\n✨ Recomendación musical activada");
        mostrarPlaylist();
    }
}