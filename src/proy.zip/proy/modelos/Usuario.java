package modelos;

public class Usuario {

    protected String nombre;
    protected String estadoAnimo;

    public Usuario(String nombre, String estadoAnimo) {

        this.nombre = nombre;
        this.estadoAnimo = estadoAnimo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEstadoAnimo() {
        return estadoAnimo;
    }

    public void mostrarUsuario() {

        System.out.println("\n👤 Usuario: " + nombre);
        System.out.println("😊 Estado de ánimo: " + estadoAnimo);
    }
}