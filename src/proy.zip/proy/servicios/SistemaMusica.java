package servicios;

import modelos.Cancion;
import modelos.Playlist;

public class SistemaMusica {

    public Playlist generarPlaylist(String estado) {

        Playlist playlist = new Playlist("MoodMusic");

        if (estado.equalsIgnoreCase("feliz")) {

            playlist.agregarCancion(
                    new Cancion("Energy Up", "Pop", 3));

            playlist.agregarCancion(
                    new Cancion("Summer Dreams", "Dance", 4));

        }

        else if (estado.equalsIgnoreCase("triste")) {

            playlist.agregarCancion(
                    new Cancion("Lonely Night", "Balada", 5));

            playlist.agregarCancion(
                    new Cancion("Blue Sky", "Acústico", 4));
        }

        else if (estado.equalsIgnoreCase("motivado")) {

            playlist.agregarCancion(
                    new Cancion("Never Stop", "Rock", 4));

            playlist.agregarCancion(
                    new Cancion("Power Run", "Electrónica", 5));
        }

        else {

            playlist.agregarCancion(
                    new Cancion("Focus Mode", "LoFi", 6));
        }

        return playlist;
    }
}
