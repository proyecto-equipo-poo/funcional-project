package interfaces;

public interface Recomendable {

    void recomendar();

}